dotnet build -c Release OpenSim.sln
