Not all of the files in this directory are licensed under the BSD license. Some of these files come with the Second Life viewer and are considered licensed under a Creative Commons License.

These files are:

- avataranimations.xml (Derivative work of viewerart.ini, Creative Commons Attribution+Share-Alike v2.5 License)
