#!/bin/sh
ulimit -s 1048576
dotnet OpenSim.dll
