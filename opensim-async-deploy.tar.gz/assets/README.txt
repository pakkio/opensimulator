README

This folder contains a collection of asset sets that should be loaded to assets server at startup
Each set has own folder, that contains a xml file, that defines all its assets, and the data files needed.
File AssetSets.xml lists all the sets to include

You can add more assets or sets. Use the provided ones as example


To add items with your assets to OpenSim Inventory library, you need to define them in folder 
bin/inventory. See that folder README file
